﻿using UnityEngine;

[RequireComponent(typeof(MeshFilter)), RequireComponent(typeof(MeshRenderer))]
public class DynamicMeshSample1 : MonoBehaviour
{
	private MeshFilter meshFilter;

	private void Start()
	{
		meshFilter = GetComponent<MeshFilter>();

		Mesh mesh = new Mesh();
		mesh.vertices = new Vector3[] { new Vector3(0f, 0f, 0f), new Vector3(0f, 0f, 1f), new Vector3(1f, 0f, 1f), new Vector3(1f, 0f, 0f) };
		mesh.triangles = new int[] { 0, 1, 3, 1, 2, 3 };

		mesh.RecalculateBounds();

		meshFilter.sharedMesh = mesh;
	}
}
