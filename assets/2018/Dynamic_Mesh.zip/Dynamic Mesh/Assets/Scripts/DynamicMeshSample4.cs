﻿using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter)), RequireComponent(typeof(MeshRenderer))]
public class DynamicMeshSample4 : MonoBehaviour
{
	private MeshFilter meshFilter;

	private MeshRenderer meshRenderer;

	[SerializeField]
	private Material material;

	private void Start()
	{
		meshFilter = GetComponent<MeshFilter>();
		meshRenderer = GetComponent<MeshRenderer>();

		List<Vector3> verts = new List<Vector3>();
		List<Vector2> uvs = new List<Vector2>();
		List<int> tris = new List<int>();
		Mesh mesh = new Mesh();

		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				int pointer = verts.Count;
				verts.Add(new Vector3(i, 0f, j));
				verts.Add(new Vector3(i, 0f, j + 1f));
				verts.Add(new Vector3(i + 1f, 0f, j + 1f));
				verts.Add(new Vector3(i + 1f, 0f, j));
				uvs.Add(new Vector2(0f, 0f));
				uvs.Add(new Vector2(0f, 1f));
				uvs.Add(new Vector2(1f, 1f));
				uvs.Add(new Vector2(1f, 0f));
				tris.Add(0 + pointer);
				tris.Add(1 + pointer);
				tris.Add(3 + pointer);
				tris.Add(1 + pointer);
				tris.Add(2 + pointer);
				tris.Add(3 + pointer);
			}
		}

		mesh.vertices = verts.ToArray();
		mesh.triangles = tris.ToArray();
		mesh.uv = uvs.ToArray();

		mesh.RecalculateBounds();
		mesh.RecalculateNormals();
		mesh.RecalculateTangents();

		meshFilter.sharedMesh = mesh;
		meshRenderer.sharedMaterial = material;
	}
}
