﻿using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter)), RequireComponent(typeof(MeshRenderer))]
public class DynamicMeshSample5 : MonoBehaviour
{
	private MeshFilter meshFilter;

	private MeshRenderer meshRenderer;

	[SerializeField]
	private Material[] materials;

	private void Start()
	{
		meshFilter = GetComponent<MeshFilter>();
		meshRenderer = GetComponent<MeshRenderer>();

		List<Vector3> verts = new List<Vector3>();
		List<Vector2> uvs = new List<Vector2>();
		List<int> tris1 = new List<int>();
		List<int> tris2 = new List<int>();
		Mesh mesh = new Mesh();

		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				int pointer = verts.Count;
				verts.Add(new Vector3(i, 0f, j));
				verts.Add(new Vector3(i, 0f, j + 1f));
				verts.Add(new Vector3(i + 1f, 0f, j + 1f));
				verts.Add(new Vector3(i + 1f, 0f, j));
				uvs.Add(new Vector2(0f, 0f));
				uvs.Add(new Vector2(0f, 1f));
				uvs.Add(new Vector2(1f, 1f));
				uvs.Add(new Vector2(1f, 0f));
				tris1.Add(0 + pointer);
				tris1.Add(1 + pointer);
				tris1.Add(3 + pointer);
				tris1.Add(1 + pointer);
				tris1.Add(2 + pointer);
				tris1.Add(3 + pointer);
			}
		}

		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				int pointer = verts.Count;
				verts.Add(new Vector3(0f, j, i));
				verts.Add(new Vector3(0f, j + 1f, i));
				verts.Add(new Vector3(0f, j + 1f, i + 1f));
				verts.Add(new Vector3(0f, j, i + 1f));
				uvs.Add(new Vector2(0f, 0f));
				uvs.Add(new Vector2(0f, 1f));
				uvs.Add(new Vector2(1f, 1f));
				uvs.Add(new Vector2(1f, 0f));
				tris2.Add(0 + pointer);
				tris2.Add(1 + pointer);
				tris2.Add(3 + pointer);
				tris2.Add(1 + pointer);
				tris2.Add(2 + pointer);
				tris2.Add(3 + pointer);
			}
		}

		mesh.vertices = verts.ToArray();
		mesh.subMeshCount = 2;
		mesh.SetTriangles(tris1, 0);
		mesh.SetTriangles(tris2, 1);
		mesh.uv = uvs.ToArray();

		mesh.RecalculateBounds();
		mesh.RecalculateNormals();
		mesh.RecalculateTangents();

		meshFilter.sharedMesh = mesh;
		meshRenderer.sharedMaterials = materials;
	}
}
